/****************************************************************************/
/*  File:       BinaryRequestBody.java                                      */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-02-04                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package org.expath.httpclient.impl;

import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.om.SequenceIterator;
import org.expath.httpclient.impl.BodyFactory.Type;

/**
 * TODO<doc>: ...
 *
 * @deprecated Implemented directly by {@code SinglePartRequestBody}.
 *
 * @author Florent Georges
 * @date   2009-02-04
 */
public class BinaryRequestBody
        extends SinglePartRequestBody
{
    public BinaryRequestBody(NodeInfo elem, SequenceIterator bodies, Type method)
            throws XPathException
    {
        super(elem, bodies, method);
    }

//    @Override
//    public void setHeaders(HeaderSet headers)
//            throws XPathException
//    {
//        super.setHeaders(headers);
//        // set the Content-Type header (if not set by the user)
//        if ( headers.getFirstHeader("Content-Type") == null ) {
//            headers.add("Content-Type", getContentType());
//        }
//    }
//
//    // Serialize to bytes.  Actually serialize to text, that must be in base64,
//    // with a wrapper output stream that decodes the base64 text to bytes on
//    // the fly.
//    @Override
//    public void serialize(OutputStream out)
//            throws XPathException
//    {
//        Properties options = getSerializationParams();
//        options.put(OutputKeys.METHOD, "text");
//        Configuration config = getBodyElement().getConfiguration();
//        OutputStream wrapper = new Base64.OutputStream(out, Base64.DECODE);
//        QueryResult.serializeSequence(getChilds(), config, wrapper, options);
//    }
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
