/****************************************************************************/
/*  File:       XmlRequestBody.java                                         */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-02-04                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package org.expath.httpclient.impl;

import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.trans.XPathException;
import org.expath.httpclient.impl.BodyFactory.Type;

/**
 * TODO<doc>: ...
 *
 * @deprecated Implemented directly by {@code SinglePartRequestBody}.
 *
 * @author Florent Georges
 * @date   2009-02-04
 */
public class XmlRequestBody
        extends  SinglePartRequestBody
{
    public XmlRequestBody(NodeInfo elem, SequenceIterator bodies, Type method)
            throws XPathException
    {
        super(elem, bodies, method);
    }

//    @Override
//    public void setHeaders(HeaderSet headers)
//            throws XPathException
//    {
//        super.setHeaders(headers);
//        // set the Content-Type header (if not set by the user)
//        if ( headers.getFirstHeader("Content-Type") == null ) {
//            // TODO: When $serial will be taken into account, maybe UTF-8 won't
//            // be correct anymore...?
//            String type = getContentType() + "; charset=utf-8";
//            headers.add("Content-Type", type);
//        }
//    }
//
//    @Override
//    public void serialize(OutputStream out)
//            throws XPathException
//    {
//        // the default serialization options
//        Properties options = getSerializationParams();
//        options.put(OutputKeys.METHOD, "xml");
//        // TODO: childs can be childs of http:body.  Even if the 'http' prefix is
//        // in @exclude-result-prefixes, its namespace declaration is serialized
//        // in the output (I guess because http:body is still the parent of
//        // childs, so ns normalization requires it.  How to do?
//        // TODO: Look for what Norm uses in Calabash.  I know I saw a post from
//        // him on the Saxon mailing list on that subject...
//        Configuration config = getBodyElement().getConfiguration();
//        QueryResult.serializeSequence(getChilds(), config, out, options);
//    }
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
