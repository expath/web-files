/****************************************************************************/
/*  File:       SinglePartRequestBody.java                                  */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-02-06                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package org.expath.httpclient.impl;

import java.io.OutputStream;
import java.util.Properties;
import javax.xml.transform.OutputKeys;
import net.iharder.Base64;
import net.sf.saxon.Configuration;
import net.sf.saxon.om.Axis;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.SingletonIterator;
import net.sf.saxon.query.QueryResult;
import net.sf.saxon.trans.XPathException;
import org.expath.httpclient.HeaderSet;
import org.expath.httpclient.HttpRequestBody;
import org.expath.httpclient.SerializationParams;
import org.expath.httpclient.impl.BodyFactory.Type;

/**
 * TODO<doc>: ...
 *
 * @author Florent Georges
 * @date   2009-02-06
 */
public class SinglePartRequestBody
        extends HttpRequestBody
{
    //
    // TODO: FIXME: Take serialization attributes into account!
    //
    public SinglePartRequestBody(NodeInfo elem, SequenceIterator bodies, Type method)
            throws XPathException
    {
        super(elem);
        myMethod = method;
        String[] attr_names = {
            "src",
            "media-type",
            "method",
            "byte-order-mark",
            "cdata-section-elements",
            "doctype-public",
            "doctype-system",
            "encoding",
            "escape-uri-attributes",
            "indent",
            "normalization-form",
            "omit-xml-declaration",
            "standalone",
            "suppress-indentation",
            "undeclare-prefixes",
            "output-version"
        };
        mySerial.setEncoding(SaxonHelper.getAttribute(elem, attr_names[7]));
        mySerial.setIndent(parseYesNo(elem, attr_names[9]));
        mySerial.setOmitXmlDecl(parseYesNo(elem, attr_names[11]));
        // ...
        {
            // FIXME: For now, most of the attrs are not supported.  Throw an
            // error if any of them is there...
            String[] NOT_SUPPORTED_ATTRS = {
                "byte-order-mark",
                "cdata-section-elements",
                "doctype-public",
                "doctype-system",
                "escape-uri-attributes",
                "normalization-form",
                "standalone",
                "suppress-indentation",
                "undeclare-prefixes",
                "output-version"
            };
            for ( int i = 0; i < NOT_SUPPORTED_ATTRS.length; ++i ) {
                String name = NOT_SUPPORTED_ATTRS[i];
                String val = SaxonHelper.getAttribute(elem, name);
                if ( val != null ) {
                    throw new XPathException("Attribute not supported yet: http:body/@" + name);
                }
            }
        }
        // check for not allowed attributes
        SaxonHelper.noOtherNCNameAttribute(elem, attr_names);
        // handle childs
        myChilds = getBodyElement().iterateAxis(Axis.CHILD);
        // If there is no content in the http:body element, take the next item
        // in the $bodies parameter.
        if ( myChilds.getAnother().next() == null ) {
            Item body = bodies.next();
            if ( body == null ) {
                throw new XPathException("There is not enough items within $bodies");
            }
            myChilds = SingletonIterator.makeIterator(body);
        }
    }

    private Boolean parseYesNo(NodeInfo elem, String attr_name)
            throws XPathException
    {
        String val = SaxonHelper.getAttribute(elem, attr_name);
        if ( val == null ) {
            return null;
        }
        else if ( "yes".equals(val) ) {
            return Boolean.TRUE;
        }
        else if ( "no".equals(val) ) {
            return Boolean.FALSE;
        }
        else {
            String msg = "Incorrect value for " + attr_name + ": " + val;
            throw new XPathException(msg);
        }
    }

    @Override
    public void setHeaders(HeaderSet headers)
            throws XPathException
    {
        // set the Content-Type header (if not set by the user)
        // TODO: "if not set by the user" -> really? To clarify within the spec.
        if ( headers.getFirstHeader("Content-Type") == null ) {
            String type = getContentType();
            // TODO: This has to be re-written when the @encoding serialization
            // param will be supported.
            if ( myMethod == Type.XML
                    || myMethod == Type.HTML
                    || myMethod == Type.XHTML
                    || myMethod == Type.TEXT ) {
                if ( mySerial.getEncoding() == null ) {
                    mySerial.setEncoding("UTF-8");
                }
                type += "; charset=" + mySerial.getEncoding();
            }
            else if ( mySerial.getEncoding() != null ) {
                throw new XPathException("Encoding is not allowed with method '" + myMethod + "'");
            }
            headers.add("Content-Type", type);
        }
    }

    @Override
    public void serialize(OutputStream out)
            throws XPathException
    {
        // the default serialization options
        Properties options = getSerializationParams();
        if ( myMethod == Type.HEX ) {
            // TODO: Add support for HEX (== "base16")
            // out = new Base16.OutputStream(out, Base16.DECODE);
            throw new XPathException("Method 'hex' not supported yet");
        }
        else if ( myMethod == Type.BINARY || myMethod == Type.BASE64 ) {
            out = new Base64.OutputStream(out, Base64.DECODE);
        }
        // TODO: childs can be childs of http:body.  Even if the 'http' prefix is
        // in @exclude-result-prefixes, its namespace declaration is serialized
        // in the output (I guess because http:body is still the parent of
        // childs, so ns normalization requires it.  How to do?
        // TODO: Look for what Norm uses in Calabash.  I know I saw a post from
        // him on the Saxon mailing list on that subject...
        Configuration config = getBodyElement().getConfiguration();
        QueryResult.serializeSequence(myChilds, config, out, options);
    }

    @Override
    public boolean isMultipart()
    {
        return false;
    }

    public Properties getSerializationParams()
            throws XPathException
    {
        Properties props = new Properties();
        // method
        switch ( myMethod ) {
            case XML:
                props.put(OutputKeys.METHOD, "xml");
                break;
            case TEXT:
                props.put(OutputKeys.METHOD, "text");
                break;
            case HTML:
                props.put(OutputKeys.METHOD, "html");
                break;
            case XHTML:
                props.put(OutputKeys.METHOD, "xhtml");
                break;
            default:
                throw new XPathException("Unsupported method! (yet): " + myMethod);
        }
        // encoding
        setOutputProperty(props, mySerial.getEncoding(), OutputKeys.ENCODING);
        // indent
        setYesNoOutputProperty(props, mySerial.getIndent(), OutputKeys.INDENT);
        // omit-xml-declaration
        setYesNoOutputProperty(props, mySerial.getOmitXmlDecl(), OutputKeys.OMIT_XML_DECLARATION);
        // TODO: Add support for other serialization parameters.
        // ...
        // return the properties
        return props;
    }

    private void setOutputProperty(Properties props, String value, String key)
    {
        if ( value != null ) {
            props.setProperty(key, value);
        }
    }

    private void setYesNoOutputProperty(Properties props, Boolean value, String key)
    {
        if ( value != null ) {
            props.setProperty(key, value ? "yes" : "no");
        }
    }

    private Type myMethod;
    private SequenceIterator myChilds;
    private SerializationParams mySerial = new SerializationParams();
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
