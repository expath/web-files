/****************************************************************************/
/*  File:       XmlResponseBody.java                                        */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-02-06                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package org.expath.httpclient.impl;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import org.expath.httpclient.TreeBuilderHelper;
import java.util.List;
import javax.xml.transform.Source;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamSource;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.trans.XPathException;
import org.apache.http.Header;
import org.ccil.cowan.tagsoup.Parser;
import org.expath.httpclient.ContentType;
import org.expath.httpclient.HeaderSet;
import org.expath.httpclient.HttpResponse;
import org.expath.httpclient.HttpResponseBody;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * TODO<doc>: ...
 *
 * @author Florent Georges
 * @date   2009-02-06
 */
public class XmlResponseBody
        implements HttpResponseBody
{
//    public XmlResponseBody(NodeInfo value, ContentType type, HeaderSet headers)
//            throws XPathException
//    {
//        myContent = value;
//        myContentType = type;
//        // TODO: ...
//        myEncoding = null;
//        myHeaders = headers;
//        myResponse = null;
//    }

    public XmlResponseBody(InputStream in, ContentType type, HeaderSet headers, XPathContext ctxt, boolean html)
            throws XPathException
    {
        // TODO: ...
        String charset = "utf-8";
        try {
            Reader reader = new InputStreamReader(in, charset);
            init(reader, type, headers, ctxt, html);
        }
        catch ( UnsupportedEncodingException ex ) {
            String msg = "not supported charset reading HTTP response: " + charset;
            throw new XPathException(msg, ex);
        }
    }

    public XmlResponseBody(Reader in, ContentType type, HeaderSet headers, XPathContext ctxt, boolean html)
            throws XPathException
    {
        init(in, type, headers, ctxt, html);
    }

    private void init(Reader in, ContentType type, HeaderSet headers, XPathContext ctxt, boolean html)
            throws XPathException
    {
        myContentType = type;
        myHeaders = headers;
        myResponse = null;
        String sys_id = "TODO-find-a-useful-systemId";
        try {
            Source src = null;
            if ( html ) {
                Parser parser = new Parser();
                parser.setFeature(Parser.namespacesFeature, true);
                parser.setFeature(Parser.namespacePrefixesFeature, true);
                InputSource input = new InputSource(in);
                src = new SAXSource(parser, input);
                src.setSystemId(sys_id);
            }
            else {
                src = new StreamSource(in, sys_id);
            }
            myContent = ctxt.getConfiguration().buildDocument(src);
        }
        catch ( SAXException ex ) {
            throw new XPathException("error parsing result HTML", ex);
        }
    }

    public void setResponse(HttpResponse response)
    {
        myResponse = response;
    }

    public void outputBody(TreeBuilderHelper b)
            throws XPathException
    {
        if ( myHeaders != null ) {
            b.outputHeaders(myHeaders);
        }
        b.startElem("body");
        b.attribute("media-type", myContentType.getValue());
        // TODO: Support other attributes as well?
        b.startContent();
        b.endElem();
    }

    public void addResultItems(List<Item> sequence)
            throws XPathException
    {
        sequence.add(myContent);
    }

    private String getHeader(String name)
            throws XPathException
    {
        HeaderSet headers = myHeaders;
        if ( headers == null ) {
            headers = myResponse.getHeaders();
        }
        // TODO: Only first one?
        Header h = headers.getFirstHeader(name);
        return h == null ? null : h.getValue();
    }

    private NodeInfo myContent;
    private ContentType myContentType;
    private HeaderSet myHeaders;
    private HttpResponse myResponse;
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
