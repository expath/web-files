package tmp.tests;

import java.io.IOException;
import java.io.OutputStream;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentProducer;
import org.apache.http.entity.EntityTemplate;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;

/**
 * The very same test as Oleg posted.
 */
public class ApacheEntityProducerOleg {

    public static void main(String[] args)
            throws IOException
    {
        EntityTemplate t = new EntityTemplate(
                new ContentProducer() {
                        public void writeTo(OutputStream outstream)
                            throws IOException {
                        outstream.write("<content/>".getBytes());
                    }
                });
        t.setContentType("application/xml");
        HttpPost httppost = new HttpPost("http://localhost:8079/");
        httppost.setEntity(t);
        DefaultHttpClient httpclient = new DefaultHttpClient();
        HttpContext localContext = new BasicHttpContext();
        HttpResponse response = httpclient.execute(httppost, localContext);
        HttpEntity entity = response.getEntity();
        System.out.println("----------------------------------------");
        System.out.println(response.getStatusLine());
        if (entity != null) {
            System.out.println("Response content length: " +
                    entity.getContentLength());
        }
        if (entity != null) {
            entity.consumeContent();
        }
    }

    static {
        System.setProperty("org.apache.commons.logging.Log",
                "org.apache.commons.logging.impl.SimpleLog");
        System.setProperty(
                "org.apache.commons.logging.simplelog.log.org.apache.http",
                "debug");
    }
}
