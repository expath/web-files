package tmp.tests;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 *
 * @author georgfl
 */
public class ArrayIterator<T>
        implements Iterator<T>
{
    public ArrayIterator(T[] array)
    {
        if ( array == null ) {
            throw new NullPointerException("Array is null.");
        }
        myArray = array;
        myNextIdx = 0;
    }

    public boolean hasNext()
    {
        return myNextIdx < myArray.length;
    }

    public T next()
    {
        if ( ! hasNext() ) {
            throw new NoSuchElementException("No more element in the array.");
        }
        return myArray[myNextIdx++];
    }

    public void remove()
    {
        throw new UnsupportedOperationException("Not supported for array wrappers.");
    }

    private T[] myArray;
    private int myNextIdx;
}
