/****************************************************************************/
/*  File:       HttpClient.java                                             */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-02-01                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package org.expath.saxon;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.om.ArrayIterator;
import net.sf.saxon.om.Axis;
import net.sf.saxon.om.AxisIterator;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.type.Type;
import net.sf.saxon.value.AtomicValue;
import net.sf.saxon.value.BooleanValue;
import net.sf.saxon.value.Whitespace;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.expath.httpclient.HeaderSet;
import org.expath.httpclient.HttpConnection;
import org.expath.httpclient.HttpConstants;
import org.expath.httpclient.HttpCredentials;
import org.expath.httpclient.HttpRequest;
import org.expath.httpclient.HttpResponse;
import org.expath.httpclient.impl.ApacheHttpConnection;
import org.expath.httpclient.impl.BodyFactory;
import org.expath.httpclient.impl.HttpRequestImpl;


/**
 * EXPath module http-client, for Saxon.
 *
 * @author Florent Georges
 * @date   2009-02-01
 */
public class HttpClient
{
    /**
     * Implement the EXPath function http:send-request().
     *
     * <pre>
     * http:send-request($request as element(http:request)?) as item()+
     * </pre>
     */
    public static SequenceIterator sendRequest(XPathContext ctxt, NodeInfo request)
            throws XPathException
    {
        return sendRequest(ctxt, request, null, null);
    }

    /**
     * Implement the EXPath function http:send-request().
     *
     * <pre>
     * http:send-request($request as element(http:request)?,
     *                   $href as xs:string?) as item()+
     * </pre>
     */
    public static SequenceIterator sendRequest(XPathContext ctxt,
                                               NodeInfo request,
                                               String href)
            throws XPathException
    {
        return sendRequest(ctxt, request, href, null);
    }

    /**
     * Implement the EXPath function http:send-request().
     *
     * <pre>
     * http:send-request($request as element(http:request)?,
     *                   $href as xs:string?,
     *                   $bodies as item()*) as item()+
     * </pre>
     */
    public static SequenceIterator sendRequest(XPathContext ctxt,
                                               NodeInfo request,
                                               String href,
                                               SequenceIterator bodies)
            throws XPathException
    {
        HttpRequest req = new HttpRequestImpl(ctxt);
        HttpClient client = new HttpClient(req);
        return client.doSendRequest(ctxt, request, href, bodies);
    }

    public HttpClient(HttpRequest req)
    {
        myRequest = req;
    }

    // TODO: Within the latest draft, $content has been changed to $bodies...
    // This is now an item()* instead of an item().
    //
    // TODO: Theoretically, the SequenceIterator should allow the
    // implementation to be streamable (for instance to not parse the
    // response content if the user does: http:send-request(...)[1],
    // that is, if he/she does not actually access the content).  See
    // if we can use that...
    private SequenceIterator doSendRequest(XPathContext ctxt,
                                           NodeInfo request,
                                           String href,
                                           SequenceIterator bodies)
            throws XPathException
    {
        myRequest.setHref(href);
        parseRequest(request, bodies);
        if ( href != null && ! "".equals(href) ) {
            myRequest.setHref(href);
        }
        try {
            URI uri = new URI(myRequest.getHref());
            HttpResponse response = sendOnce(uri, ctxt);
            List<Item> result = new ArrayList<Item>();
            result.add(response.makeResultElement());
            response.addResultItems(result);
            Item[] array = result.toArray(new Item[0]);
            return new ArrayIterator(array);
        }
        catch ( URISyntaxException ex ) {
            throw new XPathException("Href is not valid: " + myRequest.getHref(), ex);
        }
        finally {
            if ( myConnection != null ) {
                myConnection.disconnect();
            }
        }
    }

    /**
     * Send one request, not following redirect but handling authentication.
     * 
     * Authentication may require to reply to an authentication challenge,
     * by sending again the request, with credentials.
     */
    private HttpResponse sendOnce(URI uri, XPathContext ctxt)
            throws XPathException
    {
        HttpResponse response = null;
        myConnection = new ApacheHttpConnection(uri);
        if ( mySendAuth ) {
            LOG.debug("Send request with credentials.");
            response = myRequest.send(myConnection, ctxt, myCredentials);
        }
        else {
            LOG.debug("Send request without credentials.");
            response = myRequest.send(myConnection, ctxt, null);
            if ( response.getStatus() == 401 ) {
                LOG.debug("Send request with credentials on a 401.");
                myConnection.disconnect();
                myConnection = new ApacheHttpConnection(uri);
                response = myRequest.send(myConnection, ctxt, myCredentials);
            }
        }
        return response;
    }

    private void parseRequest(NodeInfo request, SequenceIterator bodies)
            throws XPathException
    {
        // check that request is element(http:request)
        if ( request == null ) {
            typeError("$request cannot be the empty sequence");
        }
        if ( request.getNodeKind() != Type.ELEMENT ) {
            typeError("$request is not an element");
        }
        if ( ! sameName(request, "request", HttpConstants.HTTP_CLIENT_NS_URI) ) {
            typeError("$request is not an element(http:request)");
        }

        String username = null;
        String password = null;
        String auth_method = null;

        // walk the attributes:
        //     method = NCName
        //     href? = anyURI
        //     status-only? = boolean
        //     username? = string
        //     password? = string
        //     auth-method? = string
        //     send-authorization? = boolean
        //     override-media-type? = string
        //     follow-redirect? = boolean
        AxisIterator attrs = request.iterateAxis(Axis.ATTRIBUTE);
        NodeInfo a;
        while ( (a = (NodeInfo) attrs.next()) != null ) {
            String local = a.getLocalPart();
            if ( !"".equals(a.getURI()) ) {
                // ignore namespace qualified attributes
            }
            else if ( "method".equals(local) ) {
                myRequest.setMethod(a.getStringValue());
            }
            else if ( "href".equals(local) ) {
                myRequest.setHref(a.getStringValue());
            }
            else if ( "http".equals(local) ) {
                myRequest.setHttpVersion(a.getStringValue().trim());
            }
            else if ( "status-only".equals(local) ) {
                String str = a.getStringValue();
                AtomicValue val = BooleanValue.fromString(str).asAtomic();
                if ( ! ( val instanceof BooleanValue ) ) {
                    typeError("http:request/@status-only is not a boolean");
                }
                BooleanValue b = (BooleanValue) val;
                myRequest.setStatusOnly(b.getBooleanValue());
            }
            else if ( "username".equals(local) ) {
                username = a.getStringValue();
            }
            else if ( "password".equals(local) ) {
                password = a.getStringValue();
            }
            else if ( "auth-method".equals(local) ) {
                auth_method = a.getStringValue();
            }
            else if ( "send-authorization".equals(local) ) {
                String str = a.getStringValue();
                AtomicValue val = BooleanValue.fromString(str).asAtomic();
                if ( ! ( val instanceof BooleanValue ) ) {
                    typeError("http:request/@send-authorization is not a boolean");
                }
                BooleanValue b = (BooleanValue) val;
                mySendAuth = b.getBooleanValue();
            }
            else if ( "override-media-type".equals(local) ) {
                myRequest.setOverrideType(a.getStringValue());
            }
            else if ( "follow-redirect".equals(local) ) {
                String str = a.getStringValue();
                AtomicValue val = BooleanValue.fromString(str).asAtomic();
                if ( ! ( val instanceof BooleanValue ) ) {
                    typeError("http:request/@follow-redirect is not a boolean");
                }
                BooleanValue b = (BooleanValue) val;
                myRequest.setFollowRedirect(b.getBooleanValue());
            }
            else {
                throw new XPathException("Unknown attribute http:request/@" + local);
            }
        }
        if ( myRequest.getMethod() == null ) {
            throw new XPathException("required @method has not been set on http:request");
        }
        if ( myRequest.getHref() == null ) {
            throw new XPathException("required @href has not been set on http:request");
        }
        if ( username != null || password != null || auth_method != null ) {
            setAuthentication(username, password, auth_method);
        }

        // walk the elements
        // TODO: Check element structure validity (header*, (multipart|body)?)
        AxisIterator childs = request.iterateAxis(Axis.CHILD);
        NodeInfo child;
        // FIXME: MUST not use SimpleHttpHeaders directly !!!
        HeaderSet headers = new HeaderSet();
        myRequest.setHeaders(headers);
        while ( (child = (NodeInfo) childs.next()) != null ) {
            String local = child.getLocalPart();
            int kind = child.getNodeKind();
            if ( kind == Type.TEXT ) {
                if ( ! Whitespace.isWhite(child.getStringValueCS()) ) {
                    throw new XPathException("Non-whitespace text nodes are not allowed");
                }
            }
            else if ( kind == Type.COMMENT || kind == Type.PROCESSING_INSTRUCTION ) {
                // ignore comment and PI nodes
            }
            else if ( kind != Type.ELEMENT ) {
                // namespace, document and attribute nodes cannot be no the child axis
                throw new XPathException("Not an element: could not happen");
            }
            else if ( "".equals(child.getURI()) ) {
                // elements in no namespace are an error
                throw new XPathException("Element in no namespace: " + local);
            }
            else if ( ! HttpConstants.HTTP_CLIENT_NS_URI.equals(child.getURI()) ) {
                // ignore elements in other namespaces
            }
            else if ( "header".equals(local) ) {
                addHeader(headers, child);
            }
            else if ( "body".equals(local) || "multipart".equals(local) ) {
                myRequest.setBody(BodyFactory.makeRequestBody(child, bodies));
            }
            else {
                throw new XPathException("Unknown element: " + local);
            }
        }
    }

    private boolean sameName(NodeInfo node, String local, String ns)
    {
        int f = node.getNamePool().getFingerprint(ns, local);
        return node.getFingerprint() == f;
    }

    private void setAuthentication(String user, String pwd, String method)
            throws XPathException
    {
        if ( LOG.isDebugEnabled() ) {
            LOG.debug("Credentials: " + user + " - *** - " + method);
        }
        if ( user == null || pwd == null || method == null ) {
            throw new XPathException("@username, @password and @auth-method must be all set");
        }
        if ( "basic".equals(method) ) {
            myCredentials = new HttpCredentials(user, pwd, method);
        }
        else if ( "digest".equals(method) ) {
            // FIXME: Wrong if HREF is not on http:request, but as a param, because
            // it will be set on myRequest after this method has been called.
            myCredentials = new HttpCredentials(user, pwd, method);
        }
        else {
            throw new XPathException("Unknown authentication method: " + method);
        }
    }

    private void addHeader(HeaderSet headers, NodeInfo e)
            throws XPathException
    {
        // walk the attributes
        AxisIterator attrs = e.iterateAxis(Axis.ATTRIBUTE);
        NodeInfo a;
        String name = null;
        String value = null;
        while ( (a = (NodeInfo) attrs.next()) != null ) {
            String local = a.getLocalPart();
            if ( !"".equals(a.getURI()) ) {
                // ignore namespace qualified attributes
            }
            else if ( "name".equals(local) ) {
                name = a.getStringValue();
            }
            else if ( "value".equals(local) ) {
                value = a.getStringValue();
            }
            else {
                throw new XPathException("Unknown attribute http:header/@" + local);
            }
        }
        // both are required
        if ( name == null || value == null ) {
            throw new XPathException("@name and @value are required on http:header");
        }
        // actually add the header
        headers.add(name, value);
    }

    private void typeError(String msg)
            throws XPathException
    {
        XPathException err = new XPathException(msg);
        err.setIsTypeError(true);
        err.setErrorCode("XPTY0004");
        throw err;
    }

    private HttpRequest myRequest;
    private HttpCredentials myCredentials = null;
    private boolean mySendAuth = false;
    private HttpConnection myConnection = null;
    private static Log LOG = LogFactory.getLog(HttpClient.class);
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
