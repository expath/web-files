/****************************************************************************/
/*  File:       HttpRequestImpl.java                                        */
/*  Author:     F. Georges - fgeorges.org                                   */
/*  Date:       2009-02-02                                                  */
/*  Tags:                                                                   */
/*      Copyright (c) 2009 Florent Georges (see end of file.)               */
/* ------------------------------------------------------------------------ */


package org.expath.httpclient.impl;

import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.trans.XPathException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.Header;
import org.expath.httpclient.ContentType;
import org.expath.httpclient.HeaderSet;
import org.expath.httpclient.HttpRequestBody;
import org.expath.httpclient.HttpConnection;
import org.expath.httpclient.HttpConstants;
import org.expath.httpclient.HttpCredentials;
import org.expath.httpclient.HttpRequest;
import org.expath.httpclient.HttpResponse;
import org.expath.httpclient.HttpResponseBody;

/**
 * TODO<doc>: ...
 *
 * @author Florent Georges
 * @date   2009-02-02
 */
public class HttpRequestImpl
        implements HttpRequest
{
    public HttpRequestImpl(XPathContext ctxt)
    {
        myCtxt = ctxt;
    }

    public HttpResponse send(HttpConnection conn, XPathContext ctxt, HttpCredentials cred)
            throws XPathException
    {
        if ( myHeaders == null ) {
            myHeaders = new HeaderSet();
        }
        conn.setRequestMethod(myMethod, myBody != null);
        conn.setRequestHeaders(myHeaders);
        if ( myHttpVer != null ) {
            conn.setHttpVersion(myHttpVer);
        }
        conn.setFollowRedirect(myFollowRedirect);
        conn.connect(myBody, cred);
        int status = conn.getResponseStatus();
        String msg = conn.getResponseMessage();
        HttpResponseBody body = null;
        if ( ! myStatusOnly ) {
            ContentType type = getContentType(conn.getResponseHeaders());
            if ( type == null ) {
                LOG.debug("There is no Content-Type, we assume there is no content");
            }
            else {
                body = BodyFactory.makeResponseBody(type, conn, ctxt);
            }
        }
        return new HttpResponse(myCtxt, status, msg, conn.getResponseHeaders(), body);
    }

    private ContentType getContentType(HeaderSet headers)
            throws XPathException
    {
        if ( myOverrideType == null ) {
            Header h = headers.getFirstHeader("Content-Type");
            if ( h == null ) {
                return null;
            }
            else {
                return new ContentType(h);
            }
        }
        else {
            return new ContentType(myOverrideType, null);
        }
    }

    public String getMethod()
    {
        return myMethod;
    }

    public void setMethod(String method)
    {
        myMethod = method;
    }

    public String getHref()
    {
        return myHref;
    }

    public void setHref(String href)
    {
        myHref = href;
    }

    public String getHttpVersion()
    {
        return myHttpVer;
    }

    public void setHttpVersion(String ver)
            throws XPathException
    {
        if ( HttpConstants.HTTP_1_0.equals(ver) ) {
            myHttpVer = HttpConstants.HTTP_1_0;
        }
        else if ( HttpConstants.HTTP_1_1.equals(ver) ) {
            myHttpVer = HttpConstants.HTTP_1_1;
        }
        else {
            throw new XPathException("Unknown HTTP version: '" + ver + "'");
        }
    }

    public void setOverrideType(String type)
    {
        myOverrideType = type;
    }

    public void setHeaders(HeaderSet headers)
    {
        myHeaders = headers;
    }

    public void setBody(HttpRequestBody body)
            throws XPathException
    {
        myBody = body;
        body.setHeaders(myHeaders);
    }

    public void setStatusOnly(boolean only)
    {
        myStatusOnly = only;
    }

    public void setFollowRedirect(boolean follow)
    {
        myFollowRedirect = follow;
    }

    private XPathContext myCtxt;
    private String myMethod;
    private String myHref;
    private String myHttpVer;
    private String myOverrideType;
    private boolean myStatusOnly;
    private boolean myFollowRedirect = true;
    private HeaderSet myHeaders;
    private HttpRequestBody myBody;
    private static final Log LOG = LogFactory.getLog(HttpRequestImpl.class);
}


/* ------------------------------------------------------------------------ */
/*  DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS COMMENT.               */
/*                                                                          */
/*  The contents of this file are subject to the Mozilla Public License     */
/*  Version 1.0 (the "License"); you may not use this file except in        */
/*  compliance with the License. You may obtain a copy of the License at    */
/*  http://www.mozilla.org/MPL/.                                            */
/*                                                                          */
/*  Software distributed under the License is distributed on an "AS IS"     */
/*  basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See    */
/*  the License for the specific language governing rights and limitations  */
/*  under the License.                                                      */
/*                                                                          */
/*  The Original Code is: all this file.                                    */
/*                                                                          */
/*  The Initial Developer of the Original Code is Florent Georges.          */
/*                                                                          */
/*  Contributor(s): none.                                                   */
/* ------------------------------------------------------------------------ */
