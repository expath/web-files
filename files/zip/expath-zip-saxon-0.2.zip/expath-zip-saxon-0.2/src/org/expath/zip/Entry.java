package org.expath.zip;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Stack;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import net.sf.saxon.om.Axis;
import net.sf.saxon.om.AxisIterator;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.trans.XPathException;

/**
 * ...
 *
 * @author Florent Georges
 * @date   2009-12-21
 */
public abstract class Entry
{
    public Entry(String path)
    {
        myPath = path;
    }

    public abstract boolean isDir();
    protected abstract void doSerialize(ZipOutputStream out, ZipEntry entry)
            throws XPathException, IOException;

    public static class Path
    {
        public void push(String step) {
            myStack.push(step);
        }
        public void pop() {
            myStack.pop();
        }
        public String getPath(boolean dir) {
            StringBuilder buf = new StringBuilder();
            for ( int i = 0, s = myStack.size(); i < s; ++i ) {
                buf.append(myStack.get(i));
                if ( i < s - 1 || dir ) {
                    buf.append('/');
                }
            }
            return buf.toString();
        }
        private Stack<String> myStack = new Stack<String>();
    }

    protected static Entry makeEntry(Path path, URI src_base, File entry)
            throws XPathException
    {
        String name = entry.getName();
        path.push(name);
        if ( ! entry.exists() ) {
            throw new XPathException("File does not exist: " + entry);
        }
        else if ( entry.isDirectory() ) {
            return new DirEntry(src_base.resolve(name + "/"), path, null);
        }
        else {
            return new FileEntry(null, null, src_base.resolve(name), path, null);
        }
    }

    public static Entry makeEntry(Path path, NodeInfo entry)
            throws XPathException
    {
        String node_name = entry.getLocalPart();
        String name = null;
        Serialization serial = new Serialization();
        String src = null;
        Boolean compress = null;
        AxisIterator attrs = entry.iterateAxis(Axis.ATTRIBUTE);
        NodeInfo a;
        while ( (a = (NodeInfo) attrs.next()) != null ) {
            String local = a.getLocalPart();
            if ( !"".equals(a.getURI()) ) {
                // ignore namespace qualified attributes
            }
            else if ( "name".equals(local) ) {
                name = a.getStringValue();
            }
            else if ( "compress".equals(local) ) {
                String s1 = a.getStringValue();
                String s2 = s1.trim();
                if ( "true".equals(s2) ) {
                    compress = true;
                }
                else if ( "false".equals(s2) ) {
                    compress = false;
                }
                else {
                    throw new XPathException("Invalid compress value:" + s1);
                }
            }
            else if ( "src".equals(local) ) {
                src = a.getStringValue();
            }
            // serialization parameters...
            else if ( "method".equals(local) ) {
                serial.setMethod(a.getStringValue());
            }
            else if ( "indent".equals(local) ) {
                serial.setIndent(a.getStringValue());
            }
            else if ( "media-type".equals(local) ) {
                serial.setMediaType(a.getStringValue());
            }
            else if ( "byte-order-mark".equals(local) ) {
                serial.setByteOrderMark(a.getStringValue());
            }
            else if ( "cdata-section-elements".equals(local) ) {
                serial.setCdataSectionElements(a.getStringValue());
            }
            else if ( "doctype-public".equals(local) ) {
                serial.setDoctypePublic(a.getStringValue());
            }
            else if ( "doctype-system".equals(local) ) {
                serial.setDoctypeSystem(a.getStringValue());
            }
            else if ( "encoding".equals(local) ) {
                serial.setEncoding(a.getStringValue());
            }
            else if ( "escape-uri-attributes".equals(local) ) {
                serial.setEscapeUriAttributes(a.getStringValue());
            }
            else if ( "normalization-form".equals(local) ) {
                serial.setNormalizationForm(a.getStringValue());
            }
            else if ( "omit-xml-declaration".equals(local) ) {
                serial.setOmitXmlDecl(a.getStringValue());
            }
            else if ( "standalone".equals(local) ) {
                serial.setStandalone(a.getStringValue());
            }
            else if ( "suppress-indentation".equals(local) ) {
                serial.setSuppressIndentation(a.getStringValue());
            }
            else if ( "undeclare-prefixes".equals(local) ) {
                serial.setUndeclarePrefixes(a.getStringValue());
            }
            else if ( "version".equals(local) ) {
                serial.setVersion(a.getStringValue());
            }
            else {
                throw new XPathException("Unknown attribute zip:" + node_name + "/@" + local);
            }
        }
        // TODO: @name can be null if there is a @src (name is initialized with
        // src basename).
        if ( name == null ) {
            if ( src == null ) {
                throw new XPathException("required @name has not been set on zip:" + node_name);
            }
            name = new File(src).getName();
        }
        path.push(name);
        if ( node_name.equals("entry") ) {
            if ( serial.getMethod() == null && src == null ) {
                throw new XPathException("required @method has not been set on zip:" + node_name);
            }
            URI src_uri = resolveSrc(src, entry);
            return new FileEntry(serial, compress, src_uri, path, entry);
        }
        else if ( ! node_name.equals("dir") ) {
            throw new XPathException("Entry is neither zip:file or zip:dir: " + entry.getDisplayName());
        }
        else if ( serial.getMethod() != null ) {
            throw new XPathException("Unknown attribute zip:dir/@method");
        }
        else if ( compress != null ) {
            throw new XPathException("Unknown attribute zip:dir/@compress");
        }
        else if ( src == null ) {
            return new DirEntry(null, path, entry);
        }
        else {
            URI src_uri = resolveSrc(src.endsWith("/") ? src : src + "/", entry);
            return new DirEntry(src_uri, path, entry);
        }
    }

    private static URI resolveSrc(String src, NodeInfo entry)
            throws XPathException
    {
        if ( src == null ) {
            return null;
        }
        try {
            URI base = new URI(entry.getBaseURI());
            return base.resolve(new URI(src));
        }
        catch ( URISyntaxException ex ) {
            String msg = "zip:entry/@src is not a valid URI: " + src;
            throw new XPathException(msg, ex);
        }
    }

    public String getPath()
    {
        return myPath;
    }

    public void serialize(ZipOutputStream out)
            throws XPathException
    {
        try {
            ZipEntry e = new ZipEntry(myPath);
            doSerialize(out, e);
            out.closeEntry();
        }
        catch ( IOException ex ) {
            throw new XPathException("Error writing entry: " + myPath, ex);
        }
    }

    private String myPath;
}
