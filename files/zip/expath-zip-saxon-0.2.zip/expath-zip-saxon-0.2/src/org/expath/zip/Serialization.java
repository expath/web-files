package org.expath.zip;

import java.util.Properties;
import javax.xml.transform.OutputKeys;
import net.sf.saxon.event.SaxonOutputKeys;
import net.sf.saxon.trans.XPathException;

/**
 * Represent a set of serialization parameters.
 *
 * @author Florent Georges
 * @date   2010-02-14
 */
public class Serialization
{
    /**
     * Return a serialization parameters map usable with JAXP.
     */
    public Properties getOutputOptions()
            throws XPathException
    {
        if ( myMethod == null ) {
            throw new XPathException("The @method serialization param is null");
        }
        Properties options = new Properties();
        options.put(OutputKeys.METHOD, myMethod);
        if ( myIndent != null ) {
            options.put(OutputKeys.INDENT, myIndent);
        }
        if ( myMediaType != null ) {
            options.put(OutputKeys.MEDIA_TYPE, myMediaType);
        }
        if ( myByteOrderMark != null ) {
            options.put(SaxonOutputKeys.BYTE_ORDER_MARK, myByteOrderMark);
        }
        if ( myCdataSectionElements != null ) {
            options.put(OutputKeys.CDATA_SECTION_ELEMENTS, myCdataSectionElements);
        }
        if ( myDoctypePublic != null ) {
            options.put(OutputKeys.DOCTYPE_PUBLIC, myDoctypePublic);
        }
        if ( myDoctypeSystem != null ) {
            options.put(OutputKeys.DOCTYPE_SYSTEM, myDoctypeSystem);
        }
        if ( myEncoding != null ) {
            options.put(OutputKeys.ENCODING, myEncoding);
        }
        if ( myEscapeUriAttributes != null ) {
            options.put(SaxonOutputKeys.ESCAPE_URI_ATTRIBUTES, myEscapeUriAttributes);
        }
        if ( myNormalizationForm != null ) {
            options.put(SaxonOutputKeys.NORMALIZATION_FORM, myNormalizationForm);
        }
        if ( myOmitXmlDecl != null ) {
            options.put(OutputKeys.OMIT_XML_DECLARATION, myOmitXmlDecl);
        }
        if ( myStandalone != null ) {
            options.put(OutputKeys.STANDALONE, myStandalone);
        }
        if ( mySuppressIndentation != null ) {
            options.put(SaxonOutputKeys.SUPPRESS_INDENTATION, mySuppressIndentation);
        }
        if ( myUndeclarePrefixes != null ) {
            options.put(SaxonOutputKeys.UNDECLARE_PREFIXES, myUndeclarePrefixes);
        }
        if ( myVersion != null ) {
            options.put(OutputKeys.VERSION, myVersion);
        }
        return options;
    }

    public String getMethod() {
        return myMethod;
    }

    public void setMethod(String value)
            throws XPathException
    {
        if ( value != null && ! ("text".equals(value)
                 || "xml".equals(value) || "html".equals(value)
                 || "xhtml".equals(value) || "base64".equals(value)
                 || "hex".equals(value)) ) {
            throw new XPathException("@method has incorrect value: " + value);
        }
        myMethod = value;
    }

    public void setIndent(String value) {
        myIndent = value;
    }

    public void setMediaType(String value) {
        myMediaType = value;
    }

    public void setByteOrderMark(String value) {
        myByteOrderMark = value;
    }

    public void setCdataSectionElements(String value) {
        myCdataSectionElements = value;
    }

    public void setDoctypePublic(String value) {
        myDoctypePublic = value;
    }

    public void setDoctypeSystem(String value) {
        myDoctypeSystem = value;
    }

    public void setEncoding(String value) {
        myEncoding = value;
    }

    public void setEscapeUriAttributes(String value) {
        myEscapeUriAttributes = value;
    }

    public void setNormalizationForm(String value) {
        myNormalizationForm = value;
    }

    public void setOmitXmlDecl(String value) {
        myOmitXmlDecl = value;
    }

    public void setStandalone(String value) {
        myStandalone = value;
    }

    public void setSuppressIndentation(String value) {
        mySuppressIndentation = value;
    }

    public void setUndeclarePrefixes(String value) {
        myUndeclarePrefixes = value;
    }

    public void setVersion(String value) {
        myVersion = value;
    }

    private String myMethod;
    private String myIndent;
    private String myMediaType;
    private String myByteOrderMark;
    private String myCdataSectionElements;
    private String myDoctypePublic;
    private String myDoctypeSystem;
    private String myEncoding;
    private String myEscapeUriAttributes;
    private String myNormalizationForm;
    private String myOmitXmlDecl;
    private String myStandalone;
    private String mySuppressIndentation;
    private String myUndeclarePrefixes;
    private String myVersion;
}
